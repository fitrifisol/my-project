<?php
include 'db.php';

  $sql = "SELECT * FROM product ";
  $result = $conn->query($sql);

  if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    $data[]=$row['productprice'];
  }
  $out = implode(",", $data);
  echo $out;
} else {
  echo "0 results";
}
$conn->close();
?>