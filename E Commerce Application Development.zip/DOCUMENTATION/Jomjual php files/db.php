<?php
$servername = "localhost";
$username = "amzarine_5st1g1";
$password = "?UJ~5#]PR5yL";
$dbname = "amzarine_5st1g1";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
?>