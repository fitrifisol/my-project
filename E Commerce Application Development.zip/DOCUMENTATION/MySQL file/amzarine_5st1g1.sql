-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Aug 07, 2021 at 02:53 AM
-- Server version: 5.7.35-cll-lve
-- PHP Version: 7.4.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `amzarine_5st1g1`
--

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `productid` int(10) NOT NULL,
  `productname` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `productdescription` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `productprice` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`productid`, `productname`, `productdescription`, `productprice`) VALUES
(1, 'Sofa Jati Terpakai', 'Harga beli asal RM 1300 jual RM 549 sahaja', 'RM 499'),
(2, 'Aquarium Glass + Silver Arowana Fish', 'Untuk diletgo aquarium kaca dan silver arowana fish', 'RM 199'),
(3, 'Katil Queen Murah', 'Untuk diletgo Katil Queen 10 Tahun Keadaan katil masih elok lagi', 'RM 249'),
(4, 'Nintendo Switch V2 Grey Fullset Maxsoft (Warranty Oct 2021)', 'Untuk diletgo Nintendo Switch V2 Grey from Maxsoft Condition outside good', 'RM 1599'),
(5, 'FULLEST DESKTOP GAMING PC AMD MURAH!!!', 'Saya ingin melepaskan FULLSET desktop light gaming saya', 'RM 499'),
(6, 'NY Yankees🔥', 'Brand New Condition new Mahal boleh offer geng', 'RM 499'),
(7, 'Ori Fitbit Inspire HR', 'Ori Kotak belum dibuka Boleh bincang harga', 'RM 200'),
(8, 'Fujifilm 35mm f1.4', 'Help friend to advertise Fujifilm XF 35mm Box set Condition good', 'RM 1700'),
(9, 'Peti Sejuk NATIONAL Single Door Fridge', 'Used Warranty 2 Bulan Semua barangan elektrik berkeadaan baik dan berfungsi', 'RM 300'),
(10, 'Gucci Sandal', '9uk Condition good Come with dustbag box paperbox n resit Buy now April 2021', 'RM 1050');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`productid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `productid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
