<?php
include 'db.php';
include 'header.php';

if(isset($_GET['contentid'])){
$contentid = $_GET['contentid'];
$sql = "SELECT * FROM content WHERE contentid=$contentid";
$result = $conn->query($sql);

if ($result->num_rows> 0) {
	//output data of each row
	while ($row = $result->fetch_assoc()) {
		$contentid = $row["contentid"];
		$userid = $row['userid'];
		$brand  = $row['brand'];
		$publishDate = $row['publishDate'];
		$description = $row['description'];
		$URL  = $row['URL'];
	}
}else {
	echo "
		<script>
		window.alert('No record found');
		</script>";
}
if (isset($_POST['submit'])) {
	$brand = $_POST['brand'];
	$publishDate = $_POST['publishDate'];
	$description = $_POST['description'];
	$URL = $_POST['URL'];	
	$sql = "UPDATE content SET  
	brand	= '$brand',
	publishDate	 = '$publishDate',
	description	 = '$description',
	URL  = '$URL',
	WHERE contentid = $contentid";
	
if ($conn->query($sql) === TRUE) {
		echo "
		<script>
		window.alert('Record updated succcessfully');
		window.location.replace('displaycontent.php');</script>";
	
	} else {
		echo "Error updating record: " . $conn->error;
	}
}
}

?>

<!DOCTYPE html>
<html>
<body>
		<div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid">
                        <h1 class="mt-4" style="text-align:center;">CMS Smartphone Company</h1></body>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item"><a href="main.html">Manage Content</a></li>
                            <li class="breadcrumb-item active">Edit Content</li>
                        </ol>
                        <div class="card mb-4">
                            <div class="card-body">
                                <p class="mb-0">
                                <b> Welcome to our official Content Management System. This system is basically about Smartphone Company's Content Management that consist the user management and content management. </b>
                                </p>
                            </div>
                        </div>
                    <div class="card mb-4">
                            <div class="card-header">
                                <i class="fas fa-list mr-1"></i>
                                Edit Content ID
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                        <thead>
                                            <tr>
                                                <th>Column</th>
												<th>Value</th>
                                               
                                            </tr>
                                        </thead>
                                       
                                        <tbody>
					<form action ="<?php echo $_SERVER['PHP_SELF']. "?contentid=$contentid";?>" method ="post">
				
					
			        <tr>
						<td>Brand</td>
						<td><input type="text" name="brand" value="<?php echo $brand;?>"></td>
					</tr>
					
					<tr>
						<td>Publish Date </td>
						<td><input type="date" name="publishDate" value="<?php echo $publishDate;?>"></td>
					</tr>
					<tr>
						<td>Description</td>
						<td><input type="text" name="description" value="<?php echo $description;?>"></td>
					</tr>
					<tr>
						<td>Source URL</td>
						<td><input type="text" name="URL" value="<?php echo $URL;?>"></td>
					</tr>
					
					</tr>
					
			        <td><input class="btn btn-info btn-block" type="submit" name="submit" value="Save"></td>
						
					</form>
				
							
	
                                        </tbody>
                                    </table>
                                </div>
							</div>
                </main>
                <footer class="py-4 bg-light mt-auto">
                    <div class="container-fluid">
                        <div class="d-flex align-items-center justify-content-between small">
                            <div class="text-muted">Copyright &copy; Tech 2021</div>
                            <div>
                                <a href="#">Privacy Policy</a>
                                &middot;
                                <a href="#">Terms &amp; Conditions</a>
                            </div>
                        </div>
                    </div>
                </footer>
            </div>
		</div>
	</div>
</html>
</body>
	
<?php
include 'footer.php';
?> 
