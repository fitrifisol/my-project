<?php 
include 'db.php';
include 'header.php';


if(isset($_POST['submit'])){
	$userid = $_SESSION['userid'];
	$brand = $_POST['brand'];
	$publishDate = $_POST['publishDate'];
	$description = $_POST['description'];
	$URL = $_POST['URL'];
	
	$sql = "INSERT INTO content (userid, brand, publishDate, description,URL)
	VALUES ('$userid', '$brand', '$publishDate', '$description', '$URL')";

							
if ($conn->query($sql) === TRUE) {
  echo "New record created successfully";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}
}
 ?>
<html>
   <body>
			<div id="layoutSidenav_content">
            <div class="container-fluid">
				</div>
				
				<h1 class="mt-4">Add Content</h1>
				<ol class="breadcrumb mb-4">
					<li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
					<li class="breadcrumb-item active"> Add New Content</li>
				</ol>
            <div class="card-body">
                <div class="table-responsive">
					<div id="dataTable_wrapper" class="dataTables_wrapper dt-bootstrap4">
						<div class="row">
							<div class="col-sm-12 col-md-6"></div>
				
						</div>
					
						<div class="row">
							<div class="col-sm-12">
								<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                       <thead>
                            <tr>
                            <th>Column</th>
							<th>Value</th>
                            </tr>
							</div>	
						</div>	
												<tbody>
						<form action="<?php echo $_SERVER['PHP_SELF'];?>" method="post">
						<tr>
							<td>Brand</td>
							<td><input type="text" name="brand" required></td>
						</tr>
						<tr>
							<td>PublishDate</td>
							<td><input type="date" name="publishDate"></td>
						</tr>
						<tr>	
							<td>Description</td>
							<td><textarea name="description"></textarea></td>
						</tr>
						<tr>
							<td>URL</td>
							<td><input type="text" name="URL" required></td>
						</tr>
						<tr>
						<td>Submit</td>
						<td><input class="btn btn-success" type="submit" name="submit" value="Save">
						<input class="btn btn-success" type="reset" name="Reset" value="Reset"></td>
						</tr>
						</form>
												</tbody>
											</table>
										</div>
									</div>
								</div>
							</div>
						</main>
		               
						<footer class="py-4 bg-light mt-auto">
							<div class="container-fluid">
								<div class="d-flex align-items-center justify-content-between small">
									<div class="text-muted">Copyright &copy; Tech 2021</div>
									<div>
										<a href="#">Privacy Policy</a>
										&middot;
										<a href="#">Terms &amp; Conditions</a>
									</div>
								</div>
							</div>
						</footer>
					</div>
				</html>	
