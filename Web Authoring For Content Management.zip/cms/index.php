<?php 
include 'db.php';
include 'header.php';
?>
            
			<div id="layoutSidenav_content">
            <div style="background-image: url('3.png')" >
                <main>
                    <div class="container ">
                        <h1 style="color:firebrick" class="mt-2"> Main</h1>
                        <ol class="breadcrumb mb-10">
                            <li class="breadcrumb-item"><a href="index.php">Main</a></li>
                            <li class="breadcrumb-item active">Page</li>
                        </ol>       
                        </div>
                        <div style="height: 200vh"></div>
                        <div class="card mb-4"><div class="card-body">When scrolling, the navigation stays at the top of the page. 
                        This is the end of the static navigation demo.</div></div>
                    </div>
                </main>
                <footer class="py-4 bg-light mt-auto">
                    <div class="container-fluid">
                        <div class="d-flex align-items-center justify-content-between small">
                            <div class="text-muted">Copyright &copy; Tech 2021</div>
                            <div>
                                <a href="#">Privacy Policy</a>
                                &middot;
                                <a href="#">Terms &amp; Conditions</a>
                            </div>
                        </div>
                    </div>
                </footer>
            </div>
<?php
include 'footer.php';
?>       
