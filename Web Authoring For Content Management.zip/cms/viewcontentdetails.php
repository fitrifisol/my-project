<?php 
include 'header.php';
 ?>
<html>
   <body>
			<div id="layoutSidenav_content">
            <div class="container-fluid">
				</div>
				
				<h1 class="mt-4">Manage Content</h1>
				<ol class="breadcrumb mb-4">
					<li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
					<li class="breadcrumb-item active"> View Content</li>
				</ol>
            <div class="card-body">
                <div class="table-responsive">
					<div id="dataTable_wrapper" class="dataTables_wrapper dt-bootstrap4">
						<div class="row">
							<div class="col-sm-12 col-md-6"></div>
				
						</div>
					
						<div class="row">
							<div class="col-sm-12">
								<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                       <thead>
                            <tr>
                            <th>Column</th>
							<th>Value</th>
                            </tr>
							</div>	
						</div>	

							<?php
								$mysqli = mysqli_connect("localhost", "root", "", "cms");
								if ($mysqli-> connect_error) {
									die("Connection failed:" . $mysqli-> connect_error);
								}
								
								if(isset($_GET['userid'])){
									$KerisId = mysqli_real_escape_string($mysqli, $_GET['userid']);
								}	
								
								$sql = "SELECT * FROM content";
								$result = $mysqli->query($sql);
		
								if ($result -> num_rows > 0) {
								while ($row = $result -> fetch_assoc()) {
										$contentid = $row['contentid'];
										$userid = $row['userid'];
								        $brand  = $row['brand'];
										$publishDate = $row['publishDate'];
										$description   = $row['description'];
										$URL  = $row['URL'];
									
									echo "<tr>
											<td> Content ID</td>
											<td> $contentid</td>
											</tr>
											<tr>
											<td> Uploader </td>
											<td> $userid</td>
											</tr>
											<td> Brand </td>
											<td> $brand</td>
											</tr>
											<tr>
											<td> Publish Date </td>
											<td> $publishDate </td>
											</tr>	
											<tr>
											<td> Description </td>
											<td> $description</td>
											</tr>
											<tr>
											<td> URL </td>
											<td> $URL</td>
											</tr>
											</tr>
											";

											
												
									
													}
													}else {
														echo "0 results";
												}
													
												?> 
									
												</tbody>
											</table>
										</div>
									</div>
								</div>
							</div>
						</main>
		               
						<footer class="py-4 bg-light mt-auto">
							<div class="container-fluid">
								<div class="d-flex align-items-center justify-content-between small">
									<div class="text-muted">Copyright &copy; Tech 2021</div>
									<div>
										<a href="#">Privacy Policy</a>
										&middot;
										<a href="#">Terms &amp; Conditions</a>
									</div>
								</div>
							</div>
						</footer>
					</div>
				</html>	
<?php
include 'footer.php';
?>