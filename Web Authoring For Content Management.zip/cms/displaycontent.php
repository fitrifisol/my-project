<?php
include 'db.php';
include 'header.php';

$sql = "SELECT * FROM content" ;
$result = $conn->query($sql);
?>
            
			<div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid">
                        <h1 class="mt-4">Content Management</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item">Content</a></li>
                            <li class="breadcrumb-item active">Data</li>
                        </ol>
                                <p class="mb-0">
                                   
                                </p>
                        </div>
                       <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">DataTables Example</h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>Content_ID</th>
                                            <th>User_ID</th>
                                            <th>Brand</th>
                                            <th>PublishDate</th>
											<th>Description</th>
											<th>URL</th>
                                            
                                        </tr>
                                    </thead>
                                    <tbody>
									<?php
									if ($result->num_rows > 0) {
									  // output data of each row
									  while($row = $result->fetch_assoc()) {
										 $contentid = $row['contentid'];
										 $userid = $row['userid'];
										 $brand = $row['brand'];
										 $publishDate = $row['publishDate'];
										 $description = $row['description'];
										 $URL = $row['URL'];
										echo "<tr>
                                            <td>$contentid</td>
											<td>$userid</td>
                                            <td>$brand</td>
                                            <td>$publishDate</td>
											<td>$description</td>
											<td><a href='" . $URL . "'>" . $URL . "</a></td>
											<td>
											<div class='btn-group'>
											<a class='btn btn-primary'href='editcontent.php?contentid=$contentid'><i class='fas fa-edit'></i> edit</a>
											<a class='btn btn-danger' href='deletecontent.php?contentid=$contentid'><i class='fas fa-trash-alt'></i>Delete</a>
											</div>
											</td>
                                           
											
                                        </tr>";
									  }
									} else {
									  echo "0 results";
									}
                                      
                                    ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
                    </div>
                </main>
                <footer class="py-4 bg-light mt-auto">
                    <div class="container-fluid">
                        <div class="d-flex align-items-center justify-content-between small">
                            <div class="text-muted">Copyright &copy; Tech 2021</div>
                            <div>
                                <a href="#">Privacy Policy</a>
                                &middot;
                                <a href="#">Terms &amp; Conditions</a>
                            </div>
                        </div>
                    </div>
                </footer>
            </div>
<?php
include 'footer.php';
?>       
