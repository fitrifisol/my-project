<?php
include 'header.php';

$sql = "SELECT * FROM user" ;
$result = $conn->query($sql);
?>
            
			<div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid">
                        <h1 class="mt-4">User Display</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item">User</a></li>
                        </ol>
                        </div>
                       <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">DataTables Example</h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>User ID</th>
                                            <th>Full Name</th>
                                            <th>Email</th>
                                            <th>Username</th>
                                        </tr>
                                    </thead>
                                    <tbody>
									<?php
									if ($result->num_rows > 0) {
									  // output data of each row
									  while($row = $result->fetch_assoc()) {
										 $userid = $row['userid'];
										 $fullname = $row['fullname'];
										 $email = $row['email'];
										 $username = $row['username'];
										echo "<tr>
                                            <td>$userid</td>
                                            <td>$fullname</td>
                                            <td>$email</td>
											<td>$username</td>
                                            <td>
											
                                        </tr>";
									  }
									} else {
									  echo "0 results";
									}
                                      
                                    ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
                    </div>
                </main>
                <footer class="py-4 bg-light mt-auto">
                    <div class="container-fluid">
                        <div class="d-flex align-items-center justify-content-between small">
                            <div class="text-muted">Copyright &copy; Tech 2021</div>
                            <div>
                                <a href="#">Privacy Policy</a>
                                &middot;
                                <a href="#">Terms &amp; Conditions</a>
                            </div>
                        </div>
                    </div>
                </footer>
            </div>
<?php
include 'footer.php';
?>       
