<?php
    
    $hostname = "localhost";
    $user 	= "amzarine_caps50";
    $password 	= "ps50@980277";
    $database 	= "amzarine_caps50";
    
    $konekci = mysqli_connect($hostname, $user, $password, $database);
 
	$Username		= $_POST['username'];
	$Password		= $_POST['password'];


                
    $sql = $konekci->query("SELECT * FROM user WHERE username='$Username' AND password='$Password'");
                
    $cek = mysqli_num_rows($sql);
    if (mysqli_num_rows($sql) > 0){
        echo "1"; 
    }
    else {
        echo "2";
    }
                    
    mysqli_close($konekci);
	
?>