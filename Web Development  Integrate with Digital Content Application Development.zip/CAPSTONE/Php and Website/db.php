<?php
$servername = "localhost";
$username = "amzarine_caps50";
$password = "ps50@980277";
$dbname = "amzarine_caps50";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
?>