<?php
include 'db.php';
$id = $_GET["id"];


    
    $query = "DELETE FROM DataKodular WHERE id='$id' ";
    $hasil_query = mysqli_query($conn, $query);

   
    if(!$hasil_query) {
      die ("Failed To Delete Data: ".mysqli_errno($conn).
       " - ".mysqli_error($conn));
    } else {
      echo "<script>alert('Data Delete Successfully.');window.location='datakodular.php';</script>";
    }