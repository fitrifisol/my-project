<?php
include 'header.php';


?>
            
			<div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid">
                        <h1 class="mt-4">Data Display</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item">Caption Creator</a></li>
                        </ol>
                        </div>
                       <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Data Tables</h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>Tajuk</th>
                                            <th>No_Gambar</th>
                                            <th>Kapsyen</th>
                                           
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php
     
	 
      $query = "SELECT * FROM DataKodular ORDER BY id ASC ";
      $result = mysqli_query($conn, $query);
  
      if(!$result){
        die ("Query Error: ".mysqli_errno($conn).
           " - ".mysqli_error($conn));
      }

      
      $no = 1; 
      
      while($row = mysqli_fetch_assoc($result))
      {
      ?>
       <tr>
          <td><?php echo $no; ?></td>
          <td><?php echo $row['Tajuk']; ?></td>
          <td><?php echo substr($row['No_Gambar'], 0, 20); ?>...</td>
          <td><?php echo substr($row['Kapsyen'], 0, 20); ?>...</td>
          <td>
          <a href="deletedatakodular.php?id=<?php echo $row['id']; ?>" onclick="return confirm('Are you sure want to delete this data?')">Delete</a>
          </td>
      </tr>
         
      <?php
        $no++; 
      }
      ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
                    </div>
                </main>
                <footer class="py-4 bg-light mt-auto">
                    <div class="container-fluid">
                        <div class="d-flex align-items-center justify-content-between small">
                            <div class="text-muted">Copyright &copy; CaptionAssist 2022</div>
                            <div>
                                <a href="#">Privacy Policy</a>
                                &middot;
                                <a href="#">Terms &amp; Conditions</a>
                            </div>
                        </div>
                    </div>
                </footer>
            </div>
<?php
include 'footer.php';
?>       
