<?php
include 'db.php';
include 'header.php';

$sql = "SELECT * FROM CaptionCreator" ;
$result = $conn->query($sql);
?>
            
			<div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid">
                        <h1 class="mt-4">Data Display</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item">Caption Creator</a></li>
                        </ol>
                        </div>
                       <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Data Tables</h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>Tajuk</th>
                                            <th>No_Gambar</th>
                                            <th>Kapsyen</th>
                                            <th>Gambar</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php
      // jalankan query untuk menampilkan semua data diurutkan berdasarkan nim
      $query = "SELECT * FROM CaptionCreator ORDER BY id ASC";
      $result = mysqli_query($conn, $query);
      //mengecek apakah ada error ketika menjalankan query
      if(!$result){
        die ("Query Error: ".mysqli_errno($conn).
           " - ".mysqli_error($conn));
      }

      //buat perulangan untuk element tabel dari data mahasiswa
      $no = 1; //variabel untuk membuat nomor urut
      // hasil query akan disimpan dalam variabel $data dalam bentuk array
      // kemudian dicetak dengan perulangan while
      while($row = mysqli_fetch_assoc($result))
      {
      ?>
       <tr>
          <td><?php echo $no; ?></td>
          <td><?php echo $row['Tajuk']; ?></td>
          <td><?php echo substr($row['No_Gambar'], 0, 20); ?>...</td>
          <td><?php echo substr($row['Kapsyen'], 0, 20); ?>...</td>
          <td style="text-align: center;"><img src="Gambar/<?php echo $row['Gambar']; ?>" style="width: 120px;"></td>
          <td>
              
              <a href="delete.php?id=<?php echo $row['id']; ?>" onclick="return confirm('Are you sure want to delete this data?')">Delete</a>
          </td>
      </tr>
         
      <?php
        $no++; //untuk nomor urut terus bertambah 1
      }
      ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
                    </div>
                </main>
                <footer class="py-4 bg-light mt-auto">
                    <div class="container-fluid">
                        <div class="d-flex align-items-center justify-content-between small">
                            <div class="text-muted">Copyright &copy; CAPTION ASSIST 2022</div>
                            <div>
                                <a href="#">Privacy Policy</a>
                                &middot;
                                <a href="#">Terms &amp; Conditions</a>
                            </div>
                        </div>
                    </div>
                </footer>
            </div>
<?php
include 'footer.php';
?>       
