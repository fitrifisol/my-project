<?php
// memanggil file koneksi.php untuk melakukan koneksi database
include 'db.php';

	// membuat variabel untuk menampung data dari form
  $Tajuk   = $_POST['Tajuk'];
  $No_Gambar     = $_POST['No_Gambar'];
  $Kapsyen    = $_POST['Kapsyen'];
  $Gambar = $_FILES['Gambar']['name'];


//cek dulu jika ada gambar produk jalankan coding ini
if($Gambar != "") {
  $ekstensi_diperbolehkan = array('png','jpg','jpeg'); //ekstensi file gambar yang bisa diupload 
  $x = explode('.', $Gambar); //memisahkan nama file dengan ekstensi yang diupload
  $ekstensi = strtolower(end($x));
  $file_tmp = $_FILES['Gambar']['tmp_name'];   
  $angka_acak     = rand(1,999);
  $nama_gambar_baru = $angka_acak.'-'.$Gambar; //menggabungkan angka acak dengan nama file sebenarnya
        if(in_array($ekstensi, $ekstensi_diperbolehkan) === true)  {     
                move_uploaded_file($file_tmp, 'Gambar/'.$nama_gambar_baru); //memindah file gambar ke folder gambar
                  // jalankan query INSERT untuk menambah data ke database pastikan sesuai urutan (id tidak perlu karena dibikin otomatis)
                  $query = "INSERT INTO CaptionCreator (Tajuk, No_Gambar, Kapsyen, Gambar) VALUES ('$Tajuk', '$No_Gambar', '$Kapsyen', '$nama_gambar_baru')";
                  $result = mysqli_query($conn, $query);
                  // periska query apakah ada error
                  if(!$result){
                      die ("Query Failed: ".mysqli_errno($conn).
                           " - ".mysqli_error($conn));
                  } else {
                    //tampil alert dan akan redirect ke halaman index.php
                    //silahkan ganti index.php sesuai halaman yang akan dituju
                    echo "<script>alert('Data Successfully Updated.');window.location='data.php';</script>";
                  }

            } else {     
             //jika file ekstensi tidak jpg dan png maka alert ini yang tampil
                echo "<script>alert('File types only support jpg, jpeg dan png.');window.location='addcontent.php';</script>";
            }
} else {
   $query = "INSERT INTO CaptionCreator (Tajuk, No_Gambar, Kapsyen) VALUES ('$Tajuk', '$No_Gambar', '$Kapsyen')";
                  $result = mysqli_query($conn, $query);
                  // periska query apakah ada error
                  if(!$result){
                      die ("Query Failed: ".mysqli_errno($conn).
                           " - ".mysqli_error($conn));
                  } else {
                    //tampil alert dan akan redirect ke halaman index.php
                    //silahkan ganti index.php sesuai halaman yang akan dituju
                    echo "<script>alert('Data Successfully Updated.');window.location='data.php';</script>";
                  }
}

 
