<?php 
include 'db.php';
include 'header.php';

 ?>
<html>
   <body>
			<div id="layoutSidenav_content">
            <div class="container-fluid">
				</div>
				
				<h1 class="mt-4">Add Caption</h1>
				<ol class="breadcrumb mb-4">
					
					<li class="breadcrumb-item active"> Add New Caption</li>
				</ol>
            <div class="card-body">
                <div class="table-responsive">
					<div id="dataTable_wrapper" class="dataTables_wrapper dt-bootstrap4">
						<div class="row">
							<div class="col-sm-12 col-md-6"></div>
				
						</div>
					
						<div class="row">
							<div class="col-sm-12">
								<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                       <thead>
                            <tr>
                            <th>Column</th>
							<th>Value</th>
                            </tr>
							</div>	
						</div>	
												<tbody>
						<form method="POST" action="addprocess.php" enctype="multipart/form-data" >
						<tr>
							<td>Tajuk</td>
							<td><input type="text" name="Tajuk" required></td>
						</tr>
						<tr>
							<td>Nombor Gambar</td>
							<td><input type="text" name="No_Gambar"></td>
						</tr>
						<tr>	
							<td>Kapsyen</td>
							<td><textarea name="Kapsyen"></textarea></td>
						</tr>
						<tr>
          					<td>Gambar</td>
         					<td><input type="file" name="Gambar" required=""></td>
						</tr>
						<tr>
						<td>Submit</td>
						<td><input class="btn btn-success" type="submit" name="submit" value="Save">
						<input class="btn btn-success" type="reset" name="Reset" value="Reset"></td>
						</tr>
						</form>
												</tbody>
											</table>
										</div>
									</div>
								</div>
							</div>
						</main>
		               
						<footer class="py-4 bg-light mt-auto">
							<div class="container-fluid">
								<div class="d-flex align-items-center justify-content-between small">
									<div class="text-muted">Copyright &copy; CAPTION ASSIST 2022</div>
									<div>
										<a href="#">Privacy Policy</a>
										&middot;
										<a href="#">Terms &amp; Conditions</a>
									</div>
								</div>
							</div>
						</footer>
					</div>
				</html>	
