<?php
require_once "db.php";
 
	$Tajuk	= $_GET['Tajuk'];
	$No_Gambar = $_GET['No_Gambar'];
    $Kapsyen  = $_GET['Kapsyen'];
    $Gambar  = $_GET['Gambar'];
    
    $sql = "INSERT INTO CaptionCreator (Gambar, Tajuk, No_Gambar, Kapsyen) VALUES ('".$Gambar."', '".$Tajuk."', '".$No_Gambar."', '".$Kapsyen."')";

     
if($conn->query($sql) === TRUE){
    echo"uSER FAILED";
}
    else
{
    echo"ERROR:" . $sql . "<br>" . $conn->error;
}
    
$conn->close(); 
       
?>