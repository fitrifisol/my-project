<?php
    
	$hostname = "localhost";
    $user = "amzarine_caps50";
    $password = "ps50@980277";
    $database = "amzarine_caps50";
   
    
    $conn = mysqli_connect($hostname, $user, $password, $database);
 
	$Img		= $_POST['Img'];


    $query = "INSERT INTO ImageKodular (Img) VALUES ('".$Img."')";

    $result = mysqli_query($conn, $query); 
    
    if($result){
        echo"1";
    }
    else
    {
        echo"2";
    }

                    
    mysqli_close($conn);
	
?>