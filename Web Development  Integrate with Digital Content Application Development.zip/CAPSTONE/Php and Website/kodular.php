<?php
 
	$hostname = "localhost";
    $user 	= "amzarine_caps50";
    $password 	= "ps50@980277";
    $database 	= "amzarine_caps50";
    
    $konekci = mysqli_connect($hostname, $user, $password, $database);
 
	$Username		= $_POST['username'];
	$Password		= $_POST['password'];

 
 
 $query = "INSERT INTO user (username, password) VALUES ('".$Username."', '".$Password."')";

$result = mysqli_query($konekci, $query); 

if($result){
    echo"1";
}
else
{
    echo"2";
}

mysqli_close($konekci); 


?>