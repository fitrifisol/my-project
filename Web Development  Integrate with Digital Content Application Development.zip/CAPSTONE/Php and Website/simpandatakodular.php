<?php

    $hostname = "localhost";
    $user 	= "amzarine_caps50";
    $password 	= "ps50@980277";
    $database 	= "amzarine_caps50";
    
    $conn = mysqli_connect($hostname, $user, $password, $database);

    $Tajuk = $_POST['Tajuk'];
    $No_Gambar = $_POST['No_Gambar'];
    $Kapsyen = $_POST['Kapsyen'];

$query = "INSERT INTO DataKodular (Tajuk, No_Gambar, Kapsyen) VALUES ('".$Tajuk."' , '".$No_Gambar."' , '".$Kapsyen."')";

$result = mysqli_query($conn, $query);

if($result){
    echo"1";
}
else
{
	echo"2";
}
mysqli_close($conn);

?>